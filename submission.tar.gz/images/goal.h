/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=40x30 goal goal.png 
 * Time-stamp: Thursday 03/28/2024, 19:25:10
 * 
 * Image Information
 * -----------------
 * goal.png 40@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GOAL_H
#define GOAL_H

extern const unsigned short goal[1200];
#define GOAL_SIZE 2400
#define GOAL_LENGTH 1200
#define GOAL_WIDTH 40
#define GOAL_HEIGHT 30

#endif

