/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 losescreen losescreen.jpeg 
 * Time-stamp: Monday 04/01/2024, 16:22:18
 * 
 * Image Information
 * -----------------
 * losescreen.jpeg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSESCREEN_H
#define LOSESCREEN_H

extern const unsigned short losescreen[38400];
#define LOSESCREEN_SIZE 76800
#define LOSESCREEN_LENGTH 38400
#define LOSESCREEN_WIDTH 240
#define LOSESCREEN_HEIGHT 160

#endif

