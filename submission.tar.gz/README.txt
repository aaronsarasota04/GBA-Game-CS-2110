A soccer game, you must score 3 goals to win. If the ball goes out of the screen or hits the red line then you automatically lose.
Press Enter to start
Control the ball using up down left right buttons
You can go back to the main screen any time by pressing back space.